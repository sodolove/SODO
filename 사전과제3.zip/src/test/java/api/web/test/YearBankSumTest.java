package api.web.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import api.task.dto.BankDto03_1;
import api.task.service.WebRestS;

@RunWith(SpringRunner.class)
@SpringBootTest
public class YearBankSumTest {

	@Autowired	
    WebRestS webRestS;

    @Test
    public void bankList() {
    	//when
    	List<BankDto03_1> list;
		try {
			list = webRestS.selectYearBankSum();
			//then
	    	BankDto03_1 b01 = list.get(0);
			assertThat(b01.getYear(), is("2014"));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
}
