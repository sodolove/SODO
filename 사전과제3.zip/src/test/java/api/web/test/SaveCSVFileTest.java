package api.web.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import api.task.repository.HugInfoRepository;
import api.task.service.WebRestS;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SaveCSVFileTest {

	@Autowired
	HugInfoRepository hugInfoRepository;
	
	@Autowired	
    WebRestS webRestS;

    @After
    public void cleanup() {
    	hugInfoRepository.deleteAll();
    }

    @Test
    public void saveCSVFile() {
    	String result = "";
        //given
    	String line = null;
		File csvFile = new File("/DoKyeong/2019��°�ä_����_��������3_���ñ����ſ뺸��_���������_������Ȳ.csv");
		BufferedReader in = null;
		List<String[]> cvsList = new ArrayList<String[]>();
		
		try {
			in = new BufferedReader(new FileReader(csvFile));
			
			line = in.readLine();
			System.out.println(line);
			String[] arrs = new String[11];
			int i=0;
			Matcher ma = Pattern.compile("(?:\\s*(?:\\\"([^\\\"]*)\\\"|([^,]+))\\s*,?)+?").matcher(line); 
			while (ma.find()) { 
				if (ma.group(1) == null) { 
					arrs[i] = ma.group(2).replace(",", "");
				} else { 
					arrs[i] = ma.group(1).replace(",", "");
				} 
				i++;
			} 
			cvsList.add(arrs);
			
			result = webRestS.saveCSVFile(cvsList);
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(in != null)
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

        //then
        assertThat(result, is("Success"));
    }
}
