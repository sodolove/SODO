package api.web.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import api.task.dto.BankDto05;
import api.task.service.WebRestS;

@RunWith(SpringRunner.class)
@SpringBootTest
public class KebankMinMaxTest {

	@Autowired	
    WebRestS webRestS;

    @Test
    public void kebankMinMax() {
    	//when
    	List<BankDto05> list;
		try {
			list = webRestS.selectKebankMinMax();
			
			//then
	    	BankDto05 b01 = list.get(0);
			assertThat(b01.getYear(), is("2017"));
			assertThat(b01.getAmount(), is(0));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    
    }
}
