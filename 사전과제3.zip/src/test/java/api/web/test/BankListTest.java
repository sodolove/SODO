package api.web.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import api.task.dto.BankDto01;
import api.task.service.WebRestS;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BankListTest {

	@Autowired	
    WebRestS webRestS;

    @Test
    public void bankList() {
    	//when
		List<BankDto01> list = webRestS.findAll();
		
		//then
		BankDto01 b01 = list.get(0);
		assertThat(b01.getInstitute_code(), is("b1"));
		assertThat(b01.getInstitute_name(), is("���õ��ñ��1"));
    
    }
    
}
