package api.web.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import api.task.dto.BankDto01;
import api.task.dto.BankDto04;
import api.task.service.WebRestS;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TopBankTest {

	@Autowired	
    WebRestS webRestS;

    @Test
    public void topBank() {
    	//when
    	BankDto04 bank;
		try {
			bank = webRestS.selectTopBank();
			
			//then
			assertThat(bank.getYear(), is("2014"));
			assertThat(bank.getBank(), is("���õ��ñ��1"));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
