package api.task.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class JwtUser
{
	/**
    private String userName;
    private String role;
    */
}
