package api.task.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import api.task.dto.BankDto03_1;
import api.task.dto.BankDto03_2;
import api.task.dto.BankDto04;
import api.task.dto.BankDto05;

@Service
public class WebRestD {

	Connection c = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	private WebRestD() throws ClassNotFoundException, SQLException {
		Class.forName("org.h2.Driver");
		c = DriverManager.getConnection("jdbc:h2:mem:testdb", "sa", "");
	}
	
	public String saveCSVFile(List<String[]> cvsList) throws SQLException {
		String result = "Success";
		
		ps = c.prepareStatement(
				"INSERT INTO HUG_INFO (YEAR,MONTH,INSTITUTE_CODE,AMOUNT) \n" +
				"VALUES (?, ?, ?, ?) "
				);

		
		for(int j=0; j < cvsList.size(); j++) {
			String[] aaaa = cvsList.get(j);
			for(int l=0;l<aaaa.length;l++) {
			}
		}
		
		for(int k=1;k < cvsList.size(); k++) {
			String[] data = cvsList.get(k);
			String year = data[0];
			String month = data[1];
			for(int i=1; i < 10; i++) {
				String amt = data[i+1];
				int amount = Integer.parseInt(amt);
				
				ps.setString(1, year);
				ps.setString(2, month);
				ps.setString(3, "b"+i);
				ps.setInt(4, amount);
				ps.executeUpdate();
			}
		}
	
		return result;
	}
	
	public List<BankDto03_1> selectYearBankSum() {
		List<BankDto03_1> list = new ArrayList<BankDto03_1>();
		try {
			ps = c.prepareStatement(
					"SELECT YEAR||'��' YEAR, SUM(AMOUNT) TOTAL_AMOUNT \n" +
					"  FROM HUG_INFO \n" +
					"GROUP BY YEAR "
					);

			rs = ps.executeQuery();
			while(rs.next()) {
				BankDto03_1 dto = new BankDto03_1();
				String year = rs.getString("YEAR");
				dto.setYear(year);
				dto.setTotal_amount(rs.getInt("TOTAL_AMOUNT"));
				
				ps = c.prepareStatement(
						"SELECT  \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b1' THEN AMOUNT END)  b1, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b2' THEN AMOUNT END)  b2, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b3' THEN AMOUNT END)  b3, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b4' THEN AMOUNT END)  b4, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b5' THEN AMOUNT END)  b5, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b6' THEN AMOUNT END)  b6, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b7' THEN AMOUNT END)  b7, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b8' THEN AMOUNT END)  b8, \n" +
			            "   SUM(CASE WHEN INSTITUTE_CODE = 'b9' THEN AMOUNT END)  b9  \n" +
						"  FROM HUG_INFO \n" +
						" WHERE YEAR = ? "
						);
				ps.setString(1, year);
				ResultSet rs2 = ps.executeQuery();
				BankDto03_2 dto03_2 = null;
				while(rs2.next()) {
					dto03_2 = new BankDto03_2();
					dto03_2.set���õ��ñ��(rs2.getString("b1"));
					dto03_2.set��������(rs2.getString("b2"));
					dto03_2.set�츮����(rs2.getString("b3"));
					dto03_2.set��������(rs2.getString("b4"));
					dto03_2.set�ѱ���Ƽ����(rs2.getString("b5"));
					dto03_2.set�ϳ�����(rs2.getString("b6"));
					dto03_2.set��������_��������(rs2.getString("b7"));
					dto03_2.set��ȯ����(rs2.getString("b8"));
					dto03_2.set��Ÿ����(rs2.getString("b9"));
				}
				rs2.close();
				dto.setDetail_amount(dto03_2);
				list.add(dto);
			}
		} catch(Exception e) {
			System.err.println("### Error [selectYearBankSum]" + e.toString());
		} finally {
			close();
		}

		return list;
	}

	public BankDto04 selectTopBank() {
		BankDto04 hug = new BankDto04();
		try {
			ps = c.prepareStatement(
					"SELECT year, institute_name bank " +
					"  FROM ( \n" +
					"       SELECT year, institute_name, sum(amount) amount \n" +
					"        FROM hug_info a, bank b \n" +
					"        WHERE a.institute_code = b.institute_code  \n" +
					"       GROUP BY a.year, b.institute_name  \n" +
					"       ORDER BY amount desc  \n" +
					"       )  \n" +
					"WHERE rownum = 1  "
					);

			rs = ps.executeQuery();
			rs.next();
			hug.setYear(rs.getString("year"));
			hug.setBank(rs.getString("bank"));
		} catch(Exception e) {
			System.err.println("### Error [selectTopBank]" + e.toString());
		} finally {
			close();
		}

		return hug;
	}

	public List<BankDto05> selectKebankMinMax() {
		List<BankDto05> list = new ArrayList<BankDto05>();
		try {
			ps = c.prepareStatement(
					"SELECT YEAR, AMOUNT \n" + 
					"  FROM ( \n" + 
					"	  SELECT YEAR, AVG(AMOUNT) AMOUNT \n" + 
					"	    FROM HUG_INFO \n" + 
					"	   WHERE INSTITUTE_CODE = 'b8' \n" + 
					"	   GROUP BY YEAR \n" + 
					"	   ORDER BY AMOUNT \n" + 
					"	 ) WHERE ROWNUM = 1 \n" + 
					" UNION ALL \n" + 
					"SELECT YEAR, AMOUNT \n" + 
					"  FROM ( \n" + 
					"    SELECT YEAR, AVG(AMOUNT) AMOUNT \n" + 
					"	   FROM HUG_INFO \n" + 
					"	  WHERE INSTITUTE_CODE = 'b8' \n" + 
					"	  GROUP BY YEAR \n" + 
					"	  ORDER BY AMOUNT DESC \n" + 
					"	) WHERE ROWNUM = 1 "
					);

			rs = ps.executeQuery();

			while(rs.next()) {
				BankDto05 dto = new BankDto05();
				dto.setYear(rs.getString("YEAR"));
				dto.setAmount(rs.getInt("AMOUNT"));
				list.add(dto);
			}
		} catch(Exception e) {
			System.err.println("### Error [selectKebankMinMax]" + e.toString());
		} finally {
			close();
		}

		return list;
	}
	
	public void close() {
		if(rs != null)
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		if(ps != null)
			try {
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
	}


}
