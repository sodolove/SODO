package api.task.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BankDto05 {

	private String year;
    private int amount;
	
}
