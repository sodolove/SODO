package api.task.dto;

import api.task.repository.Bank;
import lombok.Getter;

@Getter
public class BankDto01 {

    private String institute_code;
    private String institute_name;

    public BankDto01(Bank entity) {
        institute_code = entity.getInstitute_code();
        institute_name = entity.getInstitute_name();
    }
}
