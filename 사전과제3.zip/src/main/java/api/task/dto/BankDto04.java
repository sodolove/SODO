package api.task.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BankDto04 {
	
	private String year;
    private String bank;
    
}
