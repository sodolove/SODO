package api.task.repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class HugInfo {
	
	@Id
    @GeneratedValue
    private Long id;
	
    @Column(length = 4, nullable = false)
    private String year;

    @Column(length = 2, nullable = false)
    private String month;
    
    @Column(length = 2, nullable = false)
    private String institute_code;
    
    @Column(scale = 5, nullable = false)
    private int amount;
    
    @Builder
    public HugInfo(String year, String month, String institute_code, int amount) {
        this.year = year;
        this.month = month;
        this.institute_code = institute_code;
        this.amount = amount;
    }
}
