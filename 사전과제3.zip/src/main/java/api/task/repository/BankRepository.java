package api.task.repository;

import java.util.stream.Stream;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface BankRepository extends JpaRepository<Bank, Long> {

	 @Query("SELECT b " +
	        "  FROM Bank b" +
	        " ORDER BY id")
	 Stream<Bank> find();
}
