package api.task.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface HugInfoRepository extends JpaRepository<HugInfo, Long> {
}
