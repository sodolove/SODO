package api.task.repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
public class Bank {
	
	@Id
    @Column(length = 2, nullable = false)
    private String institute_code;

    @Column(length = 100, nullable = false)
    private String institute_name;


    @Builder
    public Bank(String institute_code, String institute_name) {
        this.institute_code = institute_code;
        this.institute_name = institute_name;
    }
}
