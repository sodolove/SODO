package api.task.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import api.task.dto.BankDto01;
import api.task.dto.BankDto04;
import api.task.service.WebRestS;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
public class WebRestC {

	private WebRestS webRestS;
	
	// 1. ������ ���Ͽ��� �� ���ڵ带 DB�� �����ϴ� API
	@PostMapping("/saveCSVFile")
    public void saveCSVFile(String filePath) {
		String line = null;
		File csvFile = new File(filePath);
		BufferedReader in = null;
		List<String[]> cvsList = new ArrayList<String[]>();
		
		try {
			in = new BufferedReader(new FileReader(csvFile));
			
			while( (line = in.readLine()) != null) {
				String[] arrs = new String[11];
				int i=0;
				Matcher ma = Pattern.compile("(?:\\s*(?:\\\"([^\\\"]*)\\\"|([^,]+))\\s*,?)+?").matcher(line); 
				while (ma.find()) { 
				    if (ma.group(1) == null) { 
				    	arrs[i] = ma.group(2).replace(",", "");
				    } else { 
				    	arrs[i] = ma.group(1).replace(",", "");
				    } 
				    i++;
				} 
				cvsList.add(arrs);
			}
			
			webRestS.saveCSVFile(cvsList);
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(in != null)
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
    }
	
	// 2. ���ñ��� ���� �������(����) ��� ��� API
	@GetMapping("/bankList")
    public List<BankDto01> bankList() {
		List<BankDto01> list = webRestS.findAll();
        return list;
    }
	
	// 3. �⵵�� �� ��������� �����ݾ� �հ� ��� API
	@GetMapping("/yearBankSum")
	public Map<String, Object> selectYearBankSum() throws ClassNotFoundException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("name", "���ñ��� ������Ȳ");
		map.put("sum", webRestS.selectYearBankSum());
		return map;
	}
	
	// 4. �� ������ �� ����� ��ü �����ݾ� �� ���� ū �ݾ��� ����� ���
	@GetMapping("/topBank")
	public BankDto04 topBank() throws ClassNotFoundException, SQLException {
		return webRestS.selectTopBank();
	}
	
	// 5. ��ü�⵵���� ��ȯ������ �����ݾ� ��� �߿��� ���� ���� �ݾװ� ū�ݾ� ���
	@GetMapping("/kebankMinMax")
	public Map<String, Object> selectKebankMinMax() throws ClassNotFoundException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("bank", "��ȯ����");
		map.put("support_amount", webRestS.selectKebankMinMax());
		return map;
	}
	
	
	
/**
 * JWT ���� �κ�, �̿ϼ�

	private UserService userService;
    private JwtService jwtService;

    @GetMapping("/api/secure/hello/{name}")
    public ResponseEntity<?> helloSecure(@PathVariable String name)
    {
        String result = String.format("Hello JWT, %s! (Secure)", name);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/api/public/hello/{name}")
    public ResponseEntity<?> helloPublic(@PathVariable String name)
    {
        String result = String.format("Hello JWT, %s! (Public)", name);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/api/public/auth")
    public ResponseEntity<?> auth(AuthDTO auth) {
        String userName = auth.getUserName();
        String passWord = auth.getPassWord();
        Boolean correctCredentials = userService.authenticate(userName, passWord);
        if (correctCredentials) {
            JwtUser jwtUser = new JwtUser(userName, passWord);
            return ResponseEntity.ok(jwtService.getToken(jwtUser));
        }
        return new ResponseEntity<>(null, HttpStatus.UNAUTHORIZED);
    } */
}
